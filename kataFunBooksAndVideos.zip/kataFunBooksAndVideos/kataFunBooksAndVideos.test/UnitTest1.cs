using NUnit.Framework;
using kataFunBooksAndVideos.Models;

namespace kataFunBooksAndVideos.test
{
    public class Tests
    {
        readonly SubscriptionProduct Item1 = new()
        {
            ProductID = "S2022001",
            Name = "Comperhensive First Aid Training",
            Type = ProductType.subscription,
            Unit = "Unit",
            UnitPrice = 20
        };
        readonly Book Item2 = new()
        {
            ProductID = "B2022002",
            Name = "The Girl on the train",
            Type = ProductType.stock,
            Unit = "Unit",
            UnitPrice = 30
        };

        readonly Customer Customer1 = new()
        {
            CustomerID = "4567890",
            EmailAddress = "a1@domain.zone",
            Address = "Address1"
        };

        readonly Customer Customer2 = new()
        {
            CustomerID = "987654",
            EmailAddress = "b2@domain.zone",
            Address = "Address2"
        };




        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ProductTest()
        {
            Members MemberDB = new();
            Member[] MemberList =
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;

            string TestCaseDescription = "UnitTest for Product Setup >> {0} ";
            Assert.AreEqual(Item1.ProductID, "S2022001", string.Format(TestCaseDescription, "SubscriptionProduct"));
            Assert.AreEqual(Item2.ProductID, "B2022002", string.Format(TestCaseDescription, "Book"));
        }

        [Test]
        public void CustomerTest()
        {
            string TestCaseDescription = "UnitTest for Customer Setup >> {0} ";
            Assert.AreEqual(Customer1.CustomerID, "4567890", string.Format(TestCaseDescription, ""));
            Assert.AreEqual(Customer2.CustomerID, "987654", string.Format(TestCaseDescription, ""));
        }

        [Test]
        public void MemberDBTest()
        {
            Members MemberDB = new();
            Member[] MemberList =
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;

            string TestCaseDescription = "UnitTest for Member Setup >> {0} ";
            Assert.AreEqual(MemberDB.MemberList[0].MemberID, "2022001", string.Format(TestCaseDescription, MemberDB.MemberList[0].MemberID));
        }

        [Test]
        public void POSetupTest()
        {
            POItem[] OrderItems1 =
            {
                new POItem {Item = Item1, ItemName = Item1.Name, Type = Item1.Type, OrderQty = 1, UnitPrice = Item1.UnitPrice, Unit = Item1.Unit },
                new POItem {Item = Item2, ItemName = Item2.Name, Type = Item2.Type, OrderQty = 2, UnitPrice = 18, Unit = Item2.Unit }
            };

            string TestCaseDescription = "UnitTest for PO Item Setup ";
            Assert.AreEqual(OrderItems1.Length, 2, TestCaseDescription);

            Members MemberDB = new();
            Member[] MemberList =
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;

            PO PO1 = new()
            {
                POID = "PO202203001",
                CustomerID = Customer1.CustomerID,
                CustomerRef = Customer1,
                Address = Customer1.Address,
                MemberRef = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0] : null,
                MemberID = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0].MemberID : "",
                Items = OrderItems1
            };
            TestCaseDescription = "UnitTest for PO Setup >> ";
            Assert.AreEqual(PO1.Items.Length, 2, string.Format(TestCaseDescription, "PO Line Item"));
            Assert.AreEqual(PO1.POID, "PO202203001", string.Format(TestCaseDescription, "PO Inserted"));
        }

        [Test]
        public void BR1Test()
        {
            POItem[] OrderItems1 =
            {
                new POItem {Item = Item1, ItemName = Item1.Name, Type = Item1.Type, OrderQty = 1, UnitPrice = Item1.UnitPrice, Unit = Item1.Unit },
                new POItem {Item = Item2, ItemName = Item2.Name, Type = Item2.Type, OrderQty = 2, UnitPrice = 18, Unit = Item2.Unit }
            };

            Members MemberDB = new();
            Member[] MemberList =
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;

            PO PO1 = new()
            {
                POID = "PO202203001",
                CustomerID = Customer1.CustomerID,
                CustomerRef = Customer1,
                Address = Customer1.Address,
                MemberRef = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0] : null,
                MemberID = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0].MemberID : "",
                Items = OrderItems1
            };
            string TestCaseDescription = "UnitTest for BR1 process >> {0}";
            Assert.AreEqual(PO1.Items.Length, 2, string.Format(TestCaseDescription, "PO Line Item"));
            Assert.AreEqual(PO1.POID, "PO202203001", string.Format(TestCaseDescription, "PO Inserted"));
            Assert.AreEqual(PO1.Total, 0, string.Format(TestCaseDescription, "PO Total Before Submit"));
            Assert.AreEqual(PO1.Slip, null, string.Format(TestCaseDescription, "Attached PO Slip Before Submit"));

            PO1.Submit(MemberDB);
            Assert.AreEqual(PO1.Total, 56, string.Format(TestCaseDescription, "PO Total after Submit"));
            Assert.AreEqual(PO1.Slip.Items.Length, 1, string.Format(TestCaseDescription, "Attached PO Slip after Submit"));
            Assert.AreEqual(PO1.Slip.Items.Length, 1, string.Format(TestCaseDescription, "Attached PO Slip after Submit"));
        }

        [Test]
        public void BR2Test()
        {

            SubscriptionProduct Item3 = new()
            {
                ProductID = "S2022002",
                Name = "Membership",
                Type = ProductType.subscription,
                Unit = "Unit",
                UnitPrice = 5
            };

            Customer Customer2 = new()
            {
                CustomerID = "987654",
                EmailAddress = "b2@domain.zone",
                Address = "Address2"
            };

            Members MemberDB = new();
            Member[] MemberList =
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;

            POItem[] OrderItems2 =
            {
                new POItem {Item = Item3, ItemName = Item3.Name, Type = Item3.Type, OrderQty = 1, UnitPrice = Item3.UnitPrice, Unit = Item3.Unit },
                new POItem {Item = Item1, ItemName = Item1.Name, Type = Item1.Type, OrderQty = 1, UnitPrice = Item1.UnitPrice, Unit = Item1.Unit }
            };

            PO PO1 = new()
            {
                POID = "PO202203002",
                CustomerID = Customer2.CustomerID,
                CustomerRef = Customer2,
                Address = Customer2.Address,
                MemberRef = (MemberDB.FindMemberByCustomerID(Customer2.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0] : null,
                MemberID = (MemberDB.FindMemberByCustomerID(Customer2.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0].MemberID : "",
                Items = OrderItems2
            };

            string TestCaseDescription = "UnitTest for BR2 process >> {0}";
            Assert.AreEqual(PO1.Items.Length, 2, string.Format(TestCaseDescription, "PO Line Item"));
            Assert.AreEqual(PO1.POID, "PO202203002", string.Format(TestCaseDescription, "PO Inserted"));
            Assert.AreEqual(PO1.MemberID, "", string.Format(TestCaseDescription, "Check membership not actived"));
            Assert.AreEqual(MemberDB.FindMemberByCustomerID(PO1.CustomerID).Length, 0, string.Format(TestCaseDescription, "Check customer is not member"));

            PO1.Submit(MemberDB);
            Assert.AreEqual(PO1.Total, 25, string.Format(TestCaseDescription, "PO Total after Submit"));
            Assert.AreEqual((PO1.MemberID != ""), true, string.Format(TestCaseDescription, "Check membership is actived"));
            Assert.AreEqual(MemberDB.FindMemberByCustomerID(PO1.CustomerID)[0].CustomerInfo.CustomerID, Customer2.CustomerID, string.Format(TestCaseDescription, "Check customer membership is activated"));

        }
    }
}