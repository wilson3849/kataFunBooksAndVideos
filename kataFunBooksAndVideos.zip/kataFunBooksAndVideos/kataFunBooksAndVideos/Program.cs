﻿using System;
using kataFunBooksAndVideos.Models;

namespace kataFunBooksAndVideos
{
    class Program
    {
        static void Main()
        {
            SubscriptionProduct Item1 = new()
            {
                ProductID = "S2022001",
                Name = "Comperhensive First Aid Training",
                Type = ProductType.subscription,
                Unit = "Unit",
                UnitPrice = 20
            };
            Book Item2 = new()
            {
                ProductID = "B2022002",
                Name = "The Girl on the train",
                Type = ProductType.stock,
                Unit = "Unit",
                UnitPrice = 30
            };
            Console.WriteLine(Item1.Name);
            Console.WriteLine(Item2.Name);

            Customer Customer1 = new()
            {
                CustomerID = "4567890",
                EmailAddress = "a1@domain.zone",
                Address = "Address1"
            };

            Members MemberDB = new();
            Member[] MemberList = 
            {
                new Member { MemberID = "2022001", Address = Customer1.Address, CustomerInfo = Customer1 },
            };
            MemberDB.MemberList = MemberList;
            Console.WriteLine(MemberDB.MemberList.Length.ToString());

            POItem[] OrderItems1 =
            {
                new POItem {Item = Item1, ItemName = Item1.Name, Type = Item1.Type, OrderQty = 1, UnitPrice = Item1.UnitPrice, Unit = Item1.Unit },
                new POItem {Item = Item2, ItemName = Item2.Name, Type = Item2.Type, OrderQty = 2, UnitPrice = 18, Unit = Item2.Unit }
            };

            PO PO1 = new()
            {
                POID = "PO202203001",
                CustomerID = Customer1.CustomerID,
                CustomerRef = Customer1,
                Address = Customer1.Address,
                MemberRef = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0] : null,
                MemberID = (MemberDB.FindMemberByCustomerID(Customer1.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0].MemberID : "",
                Items = OrderItems1
            };
            PO1.Submit(MemberDB);
            Console.WriteLine(PO1.Items.Length.ToString());
            Console.WriteLine(PO1.MemberID);
            Console.WriteLine(PO1.Total);

            SubscriptionProduct Item3 = new()
            {
                ProductID = "S2022002",
                Name = "Membership",
                Type = ProductType.subscription,
                Unit = "Unit",
                UnitPrice = 5
            };

            Customer Customer2 = new()
            {
                CustomerID = "987654",
                EmailAddress = "b2@domain.zone",
                Address = "Address2"
            };

            POItem[] OrderItems2 =
            {
                new POItem {Item = Item3, ItemName = Item3.Name, Type = Item3.Type, OrderQty = 1, UnitPrice = Item3.UnitPrice, Unit = Item3.Unit },
                new POItem {Item = Item1, ItemName = Item1.Name, Type = Item1.Type, OrderQty = 1, UnitPrice = Item1.UnitPrice, Unit = Item1.Unit }
            };

            PO PO2 = new()
            {
                POID = "PO202203002",
                CustomerID = Customer2.CustomerID,
                CustomerRef = Customer2,
                Address = Customer2.Address,
                MemberRef = (MemberDB.FindMemberByCustomerID(Customer2.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0] : null,
                MemberID = (MemberDB.FindMemberByCustomerID(Customer2.CustomerID).Length > 0) ? MemberDB.FindMemberByCustomerID(Customer1.CustomerID)[0].MemberID : "",
                Items = OrderItems2
            };


            Console.WriteLine(PO2.Items.Length.ToString());
            Console.WriteLine(PO2.MemberID);
            Console.WriteLine(MemberDB.MemberList.Length.ToString());
            Console.WriteLine(MemberDB.FindMemberByCustomerID("123").Length.ToString());

            PO2.Submit(MemberDB);

            Console.WriteLine(PO2.Items.Length.ToString());
            Console.WriteLine(PO2.MemberID);
            Console.WriteLine(MemberDB.MemberList.Length.ToString());

        }
    }
}
