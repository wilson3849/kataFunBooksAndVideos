﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kataFunBooksAndVideos.Models
{
    public class Customer
    {
        public string CustomerID { get; set; }
        public string Address { get; set; }
        public string EmailAddress { get; set; }
    }

    public class Member
    {
        public string MemberID { get; set; }
        public string Address { get; set; }
        public Customer CustomerInfo { get; set; }
    }

    public class Members
    {
        public Member[] MemberList { get; set; }

        public Member[] FindMemberByCustomerID(string CustomerID)
        {
            List<Member> MemberFound = new();
            foreach(Member M in this.MemberList)
            {
                if (M.CustomerInfo.CustomerID == CustomerID) MemberFound.Add(M);
            }
            return MemberFound.ToArray();
        }

        public Member AddMember(Customer NewMember)
        {
            List<Member> newMemberList = new();
            foreach (Member M in this.MemberList) { newMemberList.Add(M); }
            Member RegMember = new() { MemberID = Guid.NewGuid().ToString(), CustomerInfo = NewMember, Address = NewMember.Address };
            newMemberList.Add(RegMember);
            this.MemberList = newMemberList.ToArray();
            return RegMember;
        }
    }
}
