﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kataFunBooksAndVideos.Models
{
    public enum ProductType
    {
        subscription = 1,
        stock = 2
    }
    public abstract class Product
    {
        public string ProductID { get; set; }
        public ProductType Type { get; set; }
        public decimal UnitPrice { get; set; }
    }
    public class Book : Product
    {
        public string Name { get; set; }
        public string Unit { get; set; }
        public string GetName()
        {
            return string.Format("Book \"{0}\"", this.Name);
        }
    }
    public class SubscriptionProduct : Product
    {
        public string Name { get; set; }
        public string Unit { get; set; }
        public string GetName()
        {
            return string.Format("Subscription Item \"{0}\"", this.Name);
        }
    }
}
