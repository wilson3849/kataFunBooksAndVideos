﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kataFunBooksAndVideos.Models
{
    public class POItem
    {
        public object Item { get; set; }
        public string ItemName { get; set; }
        public ProductType Type { get; set; }
        public decimal OrderQty { get; set; }
        public decimal UnitPrice { get; set; }
        public string Unit { get; set; }
    }

    public class PO
    {
        public string POID { get; set; }
        public string CustomerID { get; set; }
        public Customer CustomerRef { get; set; }
        public string MemberID { get; set; }
        public Member MemberRef { get; set; }
        public string Address { get; set; }
        public string EmailAddress { get; set; }
        public POItem[] Items { get; set; }
        public string Curency { get; set; }
        public decimal Total { get; set; }
        public ShippingSlip Slip {get; set;}

        public decimal CalOrderTotal()
        {
            decimal Total = 0;
            foreach(POItem Item in Items)
            {
                Total += Item.OrderQty * Item.UnitPrice;
            }
            return Total;
        }

        public void Submit(Members MemberDB)
        {
            this.Total = CalOrderTotal();

            List<POItem> ShippingItems = new();
            foreach (POItem Item in this.Items)
            {
                if (Item.Type == ProductType.stock) ShippingItems.Add(Item);
                if (Item.ItemName == "Membership") 
                { 
                    Member RegMember = MemberDB.AddMember(this.CustomerRef);
                    this.MemberRef = RegMember;
                    this.MemberID = RegMember.MemberID;
                }
            }
            if (ShippingItems.Count > 0)
            {
                this.Slip = new()
                {
                    ShippingSlipID = this.POID,
                    CustomerID = this.CustomerID,
                    Address = this.Address,
                    Items = ShippingItems.ToArray()
                };
            }
            else
            {
                this.Slip = new();
            }
        }
    }

    public class ShippingSlip
    {
        public string ShippingSlipID { get; set; }
        public string CustomerID { get; set; }
        public string Address { get; set; }
        public POItem[] Items { get; set; }
    }
}
